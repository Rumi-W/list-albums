import AlbumModal from './AlbumModal'

export default AlbumModal
