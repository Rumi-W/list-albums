import ModalDialog from './ModalDialog'

export default ModalDialog
